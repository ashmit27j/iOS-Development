//
//  ContentView.swift
//  WeatherApp
//
//  Created by MacBook on 10/06/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack(){
            LinearGradient(colors: [.blue, .white], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            VStack(spacing: 8){
                Text("Mumbai")
                    .font(.system(size: 34, weight: .medium, design: .default))
                    .foregroundColor(.white)
                    .padding(.top, 8)
                    .shadow(radius: 5)
                VStack(spacing: 10){
                    VStack(){
                        Image(systemName: "cloud.sun.fill")
                            .renderingMode(.original)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                        Text("Partly Cloudy")
                            .font(.system(size: 26, weight: .medium, design: .default))
                            .foregroundColor(.white)
                            .shadow(radius: 5)
                        Text("35°C")
                            .font(.system(size: 72, weight: .medium, design: .default))
                            .foregroundColor(.white)
                            .shadow(radius: 5)
                    }
                    
                    HStack(spacing: 10){
                        WeatherDayView(dayOfWeek: "Tue", imageName: "cloud.sun.fill", temperature: 34)
                        WeatherDayView(dayOfWeek: "Wed", imageName: "sun.max.fill", temperature: 34)
                        WeatherDayView(dayOfWeek: "Thu", imageName: "wind.snow", temperature: 34)
                        WeatherDayView(dayOfWeek: "Fri", imageName: "wind", temperature: 34)
                        WeatherDayView(dayOfWeek: "Sat", imageName: "snow", temperature: 34)
                        WeatherDayView(dayOfWeek: "Sun", imageName: "cloud.rain", temperature: 34).foregroundColor(.white)
                    }
                }
                Spacer()
            }
        }
    }
}

#Preview {
    ContentView()
}

struct WeatherDayView: View {
    var dayOfWeek: String
    var imageName: String
    var temperature: Int
    var body: some View {
        VStack(){
            Text(dayOfWeek)
                .font(.system(size:20, weight: .medium, design: .default))
                .foregroundColor(.white)
            Image(systemName: imageName)
                .renderingMode(.original)
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
            Text("\(temperature)°")
                .font(.system(size: 28, weight: .medium, design: .default))
                .foregroundColor(.white)
        }
    }
}
