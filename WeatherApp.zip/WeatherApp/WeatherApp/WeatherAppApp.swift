//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by MacBook on 10/06/25.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
